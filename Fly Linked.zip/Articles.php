<?php
session_start();

if(isset($_SESSION['User_Name'])){}
else{
  header("location:index1.php");
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Articles You should read</title>
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="dashboard.css">
	</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#">
    <div class="img"><img src=logo2.0.png width="50" height="50" alt=""></div>
  </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="#"><?php
    echo "Welcome ".$_SESSION['User_Name'];
    ?><span class="sr-only">(current)</span></a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="dashboard.php">Feed <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="world.php">Explore the world</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="Articles.php">Articles you should read</a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Videos for YOU
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="Humourous.php">Humourous</a>
          <a class="dropdown-item" href="Motivation.php">Motivational</a>
          <a class="dropdown-item" href="comedy.php">Comedy</a>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="counsellor.php">Consult a Counsellor</a>
      </li>
    </ul>
    <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="You are Interested in" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
      <button class="btn btn-outline-danger my-2 my-sm-0" type="submit"><a href="logout.php">Log Out</a></button>
    </form>
  </div>
</nav>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<style>
  #more{display:none;}
#more1{display:none;}
#more3{display:none;}
#more4{display:none;}
#more5{display:none;}
body
{
background:black;
font-family:lato,sans-serif;
}
table, th, td {

margin:auto;
bordor-collapse:collapse;
background:black;
opacity:0.8;
color:white;
margin-top:100px;
}
th, td {
padding:20px;
opacity:0.9;
}
th {
background:orange;
color:black;
border:20px;
}
h1 {
background:url(b&w.png)no-repeat center fixed;
background-size:auto;
font-size:800%;
}
button {
background:orange;
color:black;
border:10px;
}
  </style>
  <h1>ARTICLES</h1>
<script>
function myFunction() {
  var dots = document.getElementById("dots");
  var moreText = document.getElementById("more");
  var btnText = document.getElementById("myBtn");


  if (dots.style.display === "none") {
    dots.style.display = "inline";
    btnText.innerHTML = "Read more"; 
    moreText.style.display = "none";
  } else {
    dots.style.display = "none";
    btnText.innerHTML = "Read less"; 
    moreText.style.display = "inline";
  }

}
function myFunction1() {
  var dots1 = document.getElementById("dots1");
  var moreText1 = document.getElementById("more1");
  var btnText1 = document.getElementById("myBtn1");

 if (dots1.style.display === "none") {
    dots1.style.display = "inline";
    btnText1.innerHTML = "Read more."; 
    moreText1.style.display = "none";
  } else {
    dots1.style.display = "none";
    btnText1.innerHTML = "Read less."; 
    moreText1.style.display = "inline";
  } 
}
function myFunction3() {
  var dots3 = document.getElementById("dots3");
  var moreText3 = document.getElementById("more3");
  var btnText3 = document.getElementById("myBtn3");

  if (dots3.style.display === "none") {
    dots3.style.display = "inline";
    btnText3.innerHTML = "Read more"; 
    moreText3.style.display = "none";
  } else {
    dots3.style.display = "none";
    btnText3.innerHTML = "Read less"; 
    moreText3.style.display = "inline";
  }
}
function myFunction4() {
  var dots4 = document.getElementById("dots4");
  var moreText4= document.getElementById("more4");
  var btnText4 = document.getElementById("myBtn4");

  if (dots4.style.display === "none") {
    dots4.style.display = "inline";
    btnText4.innerHTML = "Read more"; 
    moreText4.style.display = "none";
  } else {
    dots4.style.display = "none";
    btnText4.innerHTML = "Read less"; 
    moreText4.style.display = "inline";
  }
}
function myFunction5() {
  var dots5 = document.getElementById("dots5");
  var moreText5 = document.getElementById("more5");
  var btnText5 = document.getElementById("myBtn5");

  if (dots5.style.display === "none") {
    dots5.style.display = "inline";
    btnText5.innerHTML = "Read more"; 
    moreText5.style.display = "none";
  } else {
    dots5.style.display = "none";
    btnText5.innerHTML = "Read less"; 
    moreText5.style.display = "inline";
  }
}
</script>
<table style="width:100%">
<tr>
<th>S.no</th>
<th>Topic</th>
<th>Content</th>
<th>fetched from</th>
<th>Reviews</th>
</tr>
<tr>
<td>1.</td>
<td>How to stop worring</td>
<td><p>If you want to stop worrying, then you need to stop thinking so much. Thinking is a good thing of course but when you focus a lot of time over analyzing things, it can cause a lot of stress. <span id="dots">...</span><span id="more">Sometimes worrying is a good thing because it’s your mind’s way of acknowledging the importance of the situation. However, many times we worry excessively for invalid reasons. This article will give you a couple of different ways to help you to worry a little bit less.
When we worry, what we are actually doing is projecting our mind out into the future. We picture negative scenarios and images. We think about the worse possible situations. Students may spend a lot of time worrying about how they did on the test they just took. The person who is running late and is stuck in traffic is worried about what people will think of him when he shows up to the meeting late. The employee watches the news during his lunch time in the break room and sees that unemployment rate is climbing starts to worry about the security of his job. 
In all of these situations, the person is worried about something that hasn’t happened yet. Not only that, they are worried about something that they have no control over at the present moment. If you want to know how to stop worrying, then you need to learn how to be in the moment. Realize that the majority of things people worry about coming true, never come true. You can spend a great majority of your waking life worrying yourself to the point where you start to lower your happiness level. You may even start to draw back from life because you’re afraid of every possible negative situation that you have imagined in your head coming true.

So how do you just stop worrying about everything? Here’s a simple rule. If you can’t do anything to improve the situation at the moment, let it go. Stop worrying so much about things that you have no control over. The student who is worried about what score he got is just wasting his time because what’s done is done. Whether he spends his time worrying or having fun, it’s not going to change the outcome. The employee who sees the unemployment rate increasing can worry about his job and perhaps start working harder but at the moment, during his lunch, he can’t do much about it so there is no point in worrying.
A great book about this topic that you should read is called, “How to Stop Worrying and Start Living” by Dale Carnegie. The book offers a lot of great ways to help you reduce your habit of worrying. You can try writing down the things you are worried about and find out what percentage of those things actually come true. Once you realize that there was really no point in stressing over things you can do anything about and stop worrying about everything, you will start to enjoy life a lot more.</span></p><button onclick="myFunction()" id="myBtn">Read more</button></td>
<td>www.motivationalwellbeing.com</td>
<td><strong>4.5</strong></td>
</tr>
<tr>
<td>2.</td>
<td>Non-Major Depression Self Help Tips</td>
<td><p>If you are looking for some depression self help tips to feel more alive again, this article will give you some suggestions. Before you read on however, keep in mind that if you have a severe/major case of depression, get help right away. For those who have felt depressed for long periods of time, please seek professional help. Your depression may be medical related as a result of your body not being able to produce enough “feel good” chemicals. If this is the case, just motivating yourself won’t really help. Those who are already clinically depressed should know not to read this article any further.
However, if you just feel a bit down every now and then and just want some tips on how to pick yourself up, then read on.<span id="dots1">...</span><span id="more1">
Note: The term “depression” is loosely used by many people to explain sadness or feeling down. True depression is a medical term, meaning there’s something not right with your mind/body and professional help is needed. In this article however, I’ll be using the term “depression” as how most people understand it, as a temporary feeling of sadness or just not wanting to do anything just to keep things simple as most people who read this aren’t actually depressed.

Everyone goes through some stage of depression every now and then. Some people will experience it more than others. It can be a sign that something is mentally or physically wrong. Some people use it as a reason to escape their problems. Regardless of why you may feel depressed, there are some things you can do to help make yourself feel better.
If you go into any book store and go over to the self help aisle, you will be able to find many self help books. These books can help you have a better understanding of what makes you feel the way you feel and can offer you some strategies to help you feel better. These tips may or may not work depending on the severity of your problem. Let me remind you again that if you have a severe case of depression, you will want to seek professional help. There really are people who care.
Let’s get into what determines the way we feel. There are two main things. The first is how you are using your body. If you ask 100 people to describe how a depressed person walks and talks, 100 out of 100 times, you will get the same answer regardless of language and culture. The answers will include things like having a slouched back, walking slowly, breathing shallowly, and an overall downward look on the person’s face.

If I asked you to describe a happy person, would you be able to do it? Of course you can. Most likely, this person will be smiling, walking upright, breathing fully, and will generally walk faster. 
If you are feeling a bit depressed at the moment, here is an experiment you can try. What I’d like you to do first is to stand up straight. You want to have your chest stick out a little bit and have your shoulders relaxed and your back straight. The next thing I want you to do is to breathe a little bit faster. From here, look straight up at the ceiling and put the biggest grin possible on your face and leave it there for 30 seconds. 
What I’d like you to do is see if you can feel depressed without changing your body or facial expression. If you actually do this, you will find that it’s pretty much impossible. So now you know that your physiology is one major factor in the way you feel. If you want to learn more about this anxiety technique, you can read up on a science called Neuro Linguistic Programming or NLP of short. 
The other factor that will determine how you feel is what you focus on. If you walk around focusing on how your life sucks and how no one loves you or how everything in your life is a disaster, then of course you’re depressed. Tell me someone who can keep focusing on those things and not be depressed. So besides changing your body posture, another thing you will want to do is change your focus. What we focus is primarily determined by the questions that we ask ourselves on a consistent basis. 
So here is a self help for depression exercise you can do. Try to notice what type of questions you’re asking yourself on a daily basis. If it helps, you can even write it down. What you will find out is that most of those questions are negative questions that are designed to make you depressed. Every time you ask yourself a question, your mind will come up with an answer whether or not the question is valid. 
For example, if your life is going great and you ask yourself, “What is wrong with my life”, your mind will come up with an answer to that question. Ask questions like that enough times and sooner or later, you will start to feel like there really is something wrong with your life even if it was going great. If you understand this then you will realize that asking better questions can help change your focus and will therefore help you feel less depressed.
You will want to ask questions like, “What is good in my life right now? What am I most grateful for?” Now, your mind might say, “Nothing” but don’t settle for that answer. Keep asking yourself these positive questions and expect to have a positive answer and you will eventually get one. The more you focus on what is good in your life, the better you will feel. No matter what you are going through, it can be a lot worse couldn’t it? That’s something to be grateful for right there.
Again, if you want to learn more about this type of approach, read books about NLP. You can even read, “Unlimited Power” by Anthony Robbins as well. He’s a lot more entertaining to read. He basically built his career on teaching these types of techniques. The self help with depression strategy can work wonders but it may take some practice so be patient. There are lots of self help groups that you can join as well. Just remember that these techniques are for people who don’t have a severe case of depression.</span></p><button onclick="myFunction1()" id="myBtn1">Read more.</button></td>
<td>www.motivationalwellbeing.com</td>
<td><strong>4.5</strong></td>
</tr>
<tr>
<td>3.</td>
<td>Tips on Dealing with Stress</td>
<td><p>Dealing with stress is something that almost all of us have to go through. Stress isn’t always a bad thing though. It can sometimes help you to take the necessary course of action. However, in this article, I’m going to talk about the bad type of stress.<span id="dots3">...</span> <span id="more3">The one that gives you headaches and causes you to become agitated enough to yell at a stranger or to come home and kick your cat. I will also give you some tips to help you reduce stress.
So what causes stress? It can be a lot of things such as too much demand at work. Dealing with work stress can cause your days to go by really slow. Not only that, it can follow you home and cause you to get into arguments with your spouse. Since stress can cause all kinds of damage both mentally and physically, it is in your best interest to learn how to deal with it.
One way to deal with it is to ask yourself, “What can I do at this very instant to make this situation better?” Some people get stressed when they are stuck in traffic. This can be solved by realizing that there’s nothing you can do to make the situation any better. Feeling stressed isn’t going to help so why even stress about it? 

Is handling stress really that simple? How about stress at work? As long as you’re doing everything you can within your control, why stress about anything else? Most of the stuff people stress about is things they have no control over at the moment anyway. When you only focus on things that you can change, you will have a lot less on your mind. When you have a lot less on your mind, you will have a lot less stress.
There are lots of other ways of managing stress like getting a massage, doing yoga, meditation, exercise, squeezing a stress ball, and even having sex. There are a ton of other things you can do as well but these are mostly ways to get rid of stress that you already have. When you get used to only stressing over things that you can actually do something about at the moment, you will prevent a lot of the things that used to cause you stress from even happening. 
Since your stress levels will reduce dramatically, you can then use any of those other techniques to get rid of any remaining stress that you may have. Whether you’re having stress in the workplace or at home, just remember that there is no point in stressing over things that you can’t do anything to change. Focus only on things you can change and you will free yourself from pointless stress</span></p><button onclick="myFunction3()" id="myBtn3">Read more</button></td>
<td>www.motivationalwellbeing.com</td>
<td><strong>4.5</strong></td>
</tr>
<tr>
<td>4.</td>
<td>Overcoming Hopelessness</td>
<td><p>Hopelessness is a feeling that can be far more destructive than facing defeat and failure. When you are out there trying to accomplish your goals and you fail to achieve them, as long as you still have hope and faith that you will eventually reach your goals,you will keep pressing on.<span id="dots4">...</span><span id="more4">  When you feel hopeless, that’s when you are in danger of just giving up on your dreams. Let’s take a look at this specific feeling and what you can do to overcome it.
One of the main reasons why people fail to achieve their goals is because of obstacles. If you think about it though, what is a goal without obstacles? Is getting up and getting a drink of water hard for you? Of course not. That’s why it’s not considered a goal. When you attempt to accomplish something where there is a chance of failure, you are pursuing something worthwhile. As long as you believe that the goal is within your reach, you will have a chance.
Feelings of hopelessness will usually come when you have experienced defeat after defeat. After failing so many times, it can be easy to feel as if there is no point in continuing. What’s the use if you are going to end up failing again? You can sit around and feel sorry for your hopeless dreams or you can stand up and say, “So what?” So what if you don’t achieve your goals the first for 100th time you try? If you want to achieve your goals, then your approach must be about doing until. How long will you get up and try again? Until you accomplish your goal.

Hopelessness is just another word for giving up or surrendering. You feel like there is no point or no use in continuing so why bother? Well, you need to understand that many of the greatest successes and accomplishments in life came after the point where having hope was easy. It’s easy to be hopeful when you are first starting out to pursue your dreams. It’s still easy even if you are met with your first couple of challenges and obstacles. It’s when you meet your 10th one, or your 25th one, or your 100th one that having hope starts to get difficult. It’s during this time where you must not lose hope because you will be so close.
Being hopeful means to have faith. Having faith means that you know things will turn out well even if you have not evidence that it will. If you know of at least one person, living or dead, who has accomplish the goals that you have set out to accomplish, then you can use them to strengthen your resolve and your faith that if it’s possible for someone, then it’s possible for you. Hopelessness is easy. Anyone can feel that way. It’s the people who will keep going, who will never allow themselves to lose hope, are the people who achieve their goals and dreams in life.</span></p><button onclick="myFunction4()" id="myBtn4">Read more</button></td>
<td>www.motivationalwellbeing.com</td>
<td><strong>4.5</strong></td>
</tr>
<tr>
<td>5.</td>
<td>Why You Should Achieve Your Goals</td>
<td><p>Why should you do everything in your power to achieve your goals? Why should you go through the trouble of disciplining yourself to take consistent action each and every day towards your goals? Why should you have to deal with setbacks and challenges that will bring you to your knees? Why do go through any of these things just<span id="dots5">...</span><span id="more5"> to accomplish your goals? One reason is because if you don’t, you will feel regret. The second reason is because you will miss your chance to change other people’s lives.
When people get to the end of their lives, they will even feel fulfilled or full of regret. If there is something you have always wanted to do, do it. Even if there a possibility that you may fail, do it. Realize that most of the things we regret in life will come failing to take action, not taking action. In other words, we will have more regrets over the things that we didn’t do than the things that we did do. 
So when you accomplish your goals, how does that affect other people’s lives? Well, if you think about it, we are all motivated by one of two things. The first is desperation. When we become desperate, when our backs are against the wall, when there is no other choice, we will spring into action. There are hundreds of stories of people who went from being sick of being broke and living in poverty to becoming successful. The second reason people are motivated is inspiration. 

When you see someone achieve massive success, you start to believe you can to. The problem is that many people see successful people as being lucky. Now if you achieve your goal, you will be able to inspire the people around you to believe in themselves because they won’t see you as just being lucky. Whether you are trying to achieve your financial goals, fitness goals or any other kind of goal, just realize that your success or failure in achieving that goal doesn’t just affect you, it affects everyone around you.
Learning how to achieve goals and more importantly, putting what you learn into action, will help inspire others to pursue their own goals with the same determination that you had in achieving your goals. No one said living your dreams was easy, it’s not. That is why so many people end up quitting. There are far too many stories of failure and not enough stories of success. No matter how big or small your goal is, do everything you can to accomplish it. Your accomplishment can possibly inspire someone to become more than they thought they could become.</span></p><button onclick="myFunction5()" id="myBtn5">Read more</button></td>
<td>www.motivationalwellbeing.com</td>
<td><strong>4.5</strong></td>
</tr>

</table>

</body>
</html>