<?php
session_start();

if(isset($_SESSION['User_Name'])){}
else{
	header("location:login1.php");
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>User's Dashboard</title>
    </head>	
<body>
    <style>
		body{
		height: 100%;
		overflow: hidden;
		padding: 0px;
		margin: 0px;
		background-image: url("bg.jpg");
	}
	     p{
		font-size: 12px;
		font-family: helvetica;
	}
		#container{
		box-shadow: 2px 2px 10px #000000 ;
		width: 1400px;
		height: 90%;
		margin: 2% auto;
		border:2px;
		border-radius: 1%;
		overflow: hidden;
}
        #menu{
        	background: #35A1D7;
        	color: white;
        	padding: 1%;
        	font-size: 30px;
        }
        #left-col,#right-col{
        	float: left;
        	position: relative;
        	height: 90%;

        }
        .left-col{
        	 width: 20%;
    padding: 0 10px 0 0;
    float: left;
        }
        .right-col{	
     	width: 70%;
    padding: 0 10px 0 0;
    float: right;
    border:2px solid black;
        }
        #left-col-container{
        	width: 405px;
        	height:100%;
        	margin: 0px auto;
        	max-height: 600px;
    		overflow-y: scroll;      
        }
        .grey-back{
        	border:1px solid black;
        	padding: 5px;
        	background:#efefef;
        	margin: 0px auto;
        	margin-top: 2px;
        }
        #right-col-container{
        	width: 100%
        	height:100%;
        	margin: 0px auto;
        	max-height: 600px;
    		overflow-y: scroll;
        }
        #message-container{
        	height: 80%;
        	border:1px solid black; 
        }
        .textarea{
        	width: 99%;
        	margin: 0px auto;
        }
        .grey-message{
        	border:1px solid black;
        	width: 98%;
        	padding: 5px;
        	margin: 0px auto;
        	margin-top: 2px;
        	overflow: auto;
        	background-color: #35A1D7;
            font-size: 30px;
            font-family: "Times New Roman", Times, serif;
            font-style: italic;
        }
        .white-message{
        	border:1px solid black;
        	width: 98%;
        	padding: 5px;
        	margin: 0px auto;
        	margin-top: 2px;
			overflow: auto;
            font-size: 30px;        	
            font-family: "Times New Roman", Times, serif;
            font-style: italic;
        }
        #new-message{
        	box-shadow: 2px 10px 30px #000000;
        	width: 500px;
        	position: fixed;
        	top: 10%;
        	background:white;
        	z-index: 2;
        	left: 50%;
        	transform: translate(-58%, 0);
        	border-radius: 5px;
        	overflow:auto;
        	display: none;
        }
        .m-header{
        	background-color: #123070;
        	margin: 0px;
        	color:white;
        	padding:5px;
        	font-size: 20px;
        	text-align: center;
        }
        .m-footer{
        background-color: #123070;
        	margin: 0px;
        	color:white;
        	padding:5px;
        }
        .m-body{
        	padding: 5px;
        }
        .message-input{
        	width: 96%;
        }
        </style>
        <!-- Added real time functionality -->
	<div id="new-message">
		<p class="m-header">New message</p>
		<p class="m-body">
			<form align="center" method="post">
				<input type="text" list="user" onkeyup="check_in_db()" class="message-input" name="User_Name" placeholder="User_Name" id="User_Name">
				<datalist id="user"></datalist>
				<br><br>

				<textarea class="message-input" name="message" placeholder="write your message"></textarea><br>
				<input type="submit" value="send" id="send" class="send" name="send">
				<button onclick="document.getElementById('new-message').style.display='none'">Cancel</button>
			</form>
		</p>
		<p class="m-footer">Click here to send message</p>
	</div>
	<?php
	include 'connection.php';
	if(isset($_POST['send'])){
		$sender_name=$_SESSION['User_Name'];
		$reciever_name=$_POST['User_Name'];
		$message=$_POST['message'];
		$date=date("Y-m-d h:i:s");
		$q='INSERT INTO `chat` (`sender_name`,`reciever_name`,`message_text`,`date_time`)
		VALUES ("'.$sender_name.'","'.$reciever_name.'","'.$message.'","'.$date.'")';
		$r=mysqli_query($reg,$q);
		if($r){
			// echo "message sent";
			header("location:index.php?user=".$reciever_name);
		}
		else{
			echo("Error description: " . mysqli_error($reg));
		}
// 		if ($reg) {
//   echo 'connected';
// } else {
//   echo 'not connected';
// }
	}
	?>
	<script src="jquery-3.4.1.min.js"></script>
	<script>
						 document.getElementById("send").disabled = true;
		function check_in_db(){
			var User_Name=document.getElementById("User_Name").value;
		$.post("check_in_db.php",
		{
			user:"User_Name"
		},
		function(data, status){
			// alert(data);
			if(data=='<option value="no user">'){
				 document.getElementById("send").disabled = true;
			}
			else{
				 document.getElementById("send").disabled = false;
			}
			document.getElementById('user').innerHTML = data;
		}	
		);
		
		}
	</script>
<div id="container">
	<div id="menu">
		<?php
		echo $_SESSION['User_Name'];
		echo '<a style="float:right;color:white; font-size:30px;" href="logout.php">Log Out</a>';
		?>
	</div>
    <div class="left-col">
    <div id="left-col-container">
            <div style="cursor:pointer;" onclick="document.getElementById('new-message').style.display='block'" class="white-back">
                <p align="center">New Message </p>
            </div>
            <div class="grey-back">
                <?php 
    $q='SELECT DISTINCT `reciever_name`,`sender_name`
        FROM `chat` WHERE
        `sender_name`="'.$_SESSION['User_Name'].'" OR
        `reciever_name`="'.$_SESSION['User_Name'].'"
        ORDER BY `date_time` DESC ';
        $r=mysqli_query($reg, $q);
        if($r){
            if(mysqli_num_rows($r)>0){
                $counter= 0;
                $added_user=array();
                while($row= mysqli_fetch_assoc($r)){
                    $sender_name= $row['sender_name'];
                    $reciever_name= $row['reciever_name'];
                    if($_SESSION['User_Name']== $sender_name){
                        if(in_array($reciever_name, $added_user)){

                        }
                        else{
                            ?>
                            <div class="grey-back">
                            <?php echo '<a href="?user='.$reciever_name.'">'.$reciever_name.'</a>'; ?>
                            </div>
                            <?php
                            $added_user=array($counter=> $reciever_name);
                            $counter++ ;
                        }
                    }
                    elseif($_SESSION['User_Name']== $reciever_name){
                        if(in_array($sender_name, $added_user)){

                        }
                        else{
                            ?>
                            <div class="grey-back">
                            <?php echo '<a href="?user='.$sender_name.'">'.$sender_name.'</a>'; ?>
                            </div>
                            <?php
                            $added_user=array($counter=> $sender_name);
                            $counter++ ;
                        }
                    }
                }
            }
            else{
                echo 'no user';
            }

        }
        else{
            echo("Error description: " . mysqli_error($reg)); 
        }
    ?>
            </div>
        </div>
    </div>
    <div class="right-col">
    	<div id="right-col-container">
    		<div id="message-container">
    			<?php
                $no_message=false;
    			if(isset($_GET['user'])){
    				$_GET['user'] = $_GET['user'];
    			}
    			else{
    				$q='SELECT `sender_name`, `reciever_name` FROM `chat`
    				WHERE `sender_name`="'.$_SESSION['User_Name'].'"
    				or `reciever_name` = "'.$_SESSION['User_Name'].'"
    				ORDER BY `date_time` DESC LIMIT 1 ';
    				$r= mysqli_query($reg,$q);
    				if($r){
    					if(mysqli_num_rows($r)>0){
    						while($row=mysqli_fetch_assoc($r)){
    							$sender_name=$row['sender_name'];
    							$reciever_name=$row['reciever_name'];
    							if($_SESSION['User_Name']==$sender_name){
    								$_GET['user']=$reciever_name;
    							}
    							else{
    								$_GET['user']=$sender_name;
    							}
    						}
    					}
    					else if(mysqli_num_rows($r)==0){
    						echo 'no messages from you';
                            $no_message=true;
    					}
    					else{
						echo("Error description: " . mysqli_error($reg));

    					}
    				}
                }
                if($no_message==false){
    			$q='SELECT * FROM `chat` WHERE
    			`sender_name`="'.$_SESSION['User_Name'].'"
    			AND `reciever_name`= "'.$_GET['user'].'"
    			OR 
    			`sender_name`= "'.$_GET['user'].'"
    			AND `reciever_name`= "'.$_SESSION['User_Name'].'" ';
    	$r=mysqli_query($reg,$q);
		if($r){
			// echo "message sent";
			while($row= mysqli_fetch_assoc($r)){
				$sender_name= $row['sender_name'];
				$reciever_name= $row['reciever_name'];
				$message= $row['message_text'];
				if($sender_name == $_SESSION['User_Name']){
					// show the message with orange back
					?>
					<div class="grey-message">
    			<a href="#"><font color="white">Me</font></a>
    			<p><?php echo $message; ?></p>
    		</div>		
					<?php
				}
				else{
					// show the message with white back
					?>
					<div class="white-message">
    			<a href="#"><font color="white"><?php echo $sender_name; ?></font></a>
    			<p><?php echo $message; ?></p>
    		</div>
					<?php
				}
			}
		}
		else{
			echo("Error description: " . mysqli_error($reg));
		}		
    }
    			?>
    		
    		</div>
    	</div>
    	<form method="post" id="message-form">
    	<textarea class="textarea" id="message_text" placeholder="Write your message"></textarea>
    	</form>
    </div>
    <script src="jquery-3.4.1.min.js"></script>
    <script>
    	$("document").ready(function(event){
    		$("#right-col-container").on('submit','#message-form',function(){
    			var message_text=$("#message_text").val();
    			$.post("sending_process.php?user=<?php echo $_GET['user']; ?>",{
    				text: message_text,
    			},
    			function(data, status){
    				alert(data);
    				$("#message_text").val("");
    				document.getElementById("message-container").innerHTML += data;
    			}
    			);
    		});
    		$("#right-col-container").keypress(function(e){
    			if(e.keyCode==13 && !e.shiftKey){
    				$("#message-form").submit();
    			}
    		});
    	});
    </script>
</div>
</body>
</html>
