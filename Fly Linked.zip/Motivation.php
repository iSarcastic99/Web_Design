<?php
session_start();

if(isset($_SESSION['User_Name'])){}
else{
  header("location:login1.php");
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Motivational</title>
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="dashboard.css">
	</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#">
    <div class="img"><img src=logo2.0.png width="50" height="50" alt=""></div>
  </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="#"><?php
    echo "Welcome ".$_SESSION['User_Name'];
    ?><span class="sr-only">(current)</span></a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="dashboard.php">Feed <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="world.php">Explore the world</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="Articles.php">Articles you should read</a>
      </li>
      <li class="nav-item active dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        Motivational
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="Humourous.php">Humourous</a>
          <a class="dropdown-item" href="Motivational.php">Motivational</a>
          <a class="dropdown-item" href="comedy.php">Comedy</a>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="counsellor.php">Consult a Counsellor</a>
      </li>
    </ul>
    <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="You are Interested in" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
      <button class="btn btn-outline-danger my-2 my-sm-0" type="submit"><a href="logout.php">Log Out</a></button>
    </form>
  </div>
</nav>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<style>
  body{
background-image:bg.jpg;
background-color:black;
}


.mv{
float:left;
text-align:center;
width:280px;
border:1px solid grey;
margin:15px;
padding:10px;
color:White;
}

 .content{
position:fixed;
top:80;
height:100%;
right:22%;
width:76%;
overflow:scroll;
overflow-x:hidden;
overflow-y:scroll;
padding:0;


}

.search{
position:fixed;
top:70;
height:100%;
right:0%;
width:20%;
margin:0;
padding:zero;

}
.sbar{
position:fixed;
top:70;
height:120;
right:0%;
width:20%;
}
.sbar input[type=text]{
padding:6px 40px;
border-radius:20px;
}

.scontent{
position:fixed;
top:104;
height:100%;
right:0%;
width:21%;
padding:0;
overflow:scroll;
overflow-x:hidden;
overflow-y:scroll;
}
a:link{
text-decoration:none;
}
button{
float:left;
width:45%;
background-color:Black;
border-color:orange;
color:orange;
border-radius:20px;
margin:6px;
}

#myUL {
  overview:hidden;  
 list-style-type: none;
  padding: 0;
  margin: 0;
 display:nonke;
}
#myUL li a {
  border: 1px solid #ddd;
   margin-top: -1px; /* Prevent double borders */
  background-color:Black;
  padding:10px;
  text-decoration: none;
  font-size: 18px;
  color: black;
  display: block;
}

#myUL li a:hover:not(.header) {
  background-color:orange;
}

</style>
<div style="color:orange">
<center><h1> MOTIVATIONAL VIDEOS</h1><center>
</div>
<div class="content">
<div class="mv" id="mv1"><img src="m/img1.jpg" style="width:100%">
In this video you'll understand that everything is possible. You'll understand how Robert
 Downey Jr rose from buttom and become a superhero."Remember that just because you hit bottom doesn't mean you have to stay there."<br>
<button><a href="https://youtu.be/EZF8iD-wwOU">
<font color="white">Watch</a></button>
<button onclick="removeElement1()">Already Watched</font></button>
</div>

<div class="mv" id="mv2"><img src="m/img2.jpg" style="width:100%">
Dr. Tali Sharot is a neuroscientist at University College London and the 
director of the Affective Brain Lab.Her research focuses on how emotion, motivation and social factures influence our expectations, 
decisions and memories.<br>
<button><a href="https://youtu.be/xp0O2vi8DX4">
<font color="white">Watch</a></button>
<button onclick="removeElement2()">Already Watched</font></button>
</div>

<div class="mv" id="mv3"><img src="m/img3.jpg" style="width:100%">
Dwayne "The Rock" Johnson broke the internet with his speech.You will be inspired and motivated to go out
 there and achieve your goals. He states that you need to remember the hard times in your life when you are working towards your goals.<br>
<button><a href="https://youtu.be/W5tlGJwvmCQ">
<font color="white">Watch</a></button>
<button onclick="removeElement3()">Already Watched</font></button>

</div>
<div class="mv" id="mv4"><img src="m/img4.jpg" style="width:100%">
Steve Harvey Motivational Story. How his derams came true ? Steve was a homeless and lived in his car for 3 years at the age of 27. He was poor and was a failure. 
Here's his big break, rags to riches, poor to rich success story. 
<br><button><a href="https://youtu.be/LngxdiwFpno">
<font color="white">Watch</a></button>
<button onclick="removeElement4()">Already Watched</font></button>
</div>


<div class="mv" id="mv5"><img src="m/img5.jpg" style="width:100%">
Arnold Schwarzenegger talks about the six rules about success and what people need to focus on in order to succed.
 You have to work hard in order to get your goals because their is no shortcuts to success.
<br> 
<br><button><a href="https://youtu.be/eWJVvNptHZ4">
<font color="white">Watch</a></button>
<button onclick="removeElement5()">Already Watched</font></button>
</div>


<div class="mv" id="mv6"><img src="m/img6.jpg" style="width:100%">
When you start anything, the first step, you're excited. After some moment the enthusiasm from the begining starts to fade out.You lost sight of the long term goal, 
and the passion dried up. Then you began to realize.<br>
<button><a href="https://youtu.be/Thj5jl2E_Yg">
<font color="white">Watch</a></button>
<button onclick="removeElement6()">Already Watched</font></button>
</div>

<div class="mv" id="mv7"><img src="m/img7.jpg" style="width:100%">
Mtivation is a powerful,yet tricky beast.Sometimes it is really easy to get motivated,and you find yourself wrapped up in a whirlwind of 
excitement.This video contains ideas and research on how to gwt motivated.<br> 
<button><a href="https://youtu.be/g8VRisX_4GU">
<font color="white">Watch</a></button>
<button onclick="removeElement7()">Already Watched</font></button>
</div>

<div class="mv" id="mv8"><img src="m/img8.jpg" style="width:100%">
Never be afraid to go after the life you want to live. Not your parents, not society.YOUR DREAM.Be you. Go after everything you want in life.
It doesn't matter how slowly you go as long as you do not stop...<br>   
<button><a href="https://youtu.be/g-jwWYX7Jlo">
<font color="white">Watch</a></button>
<button onclick="removeElement8()">Already Watched</font></button>
</div>

<div class="mv" id="mv9"><img src="m/img9.jpg" style="width:100%">
Motivational speech by Elon Musk on "Against All Odds". Take time to identify the real problems and work on solving them. Think big. Never give up. 
 Life's unfair and people don't always agree with you. <br>
<button><a href="https://youtu.be/k9zTr2MAFRg">
<font color="white">Watch</a></button>
<button onclick="removeElement9()">Already Watched</font></button>
</div>

<div class="mv" id="mv10"><img src="m/img10.jpg"style="width:100%">
J.K Rowling is one of the most montivational and inspiration people who showed the world how determination and faith can pull you through 
 just about anything, and the hard work really does pay off.<br>
<button><a href="https://youtu.be/L2rR5RuJEPc">
<font color="white">Watch</a></button>
<button onclick="removeElement10()">Already Watched</font></button>
</div>

</div>

<div class="search">
<div class="sbar">
<input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search for Topics" title="Topic search">
</div>
<div class="scontent">
<ul id="myUL">

<li><a href="https://youtu.be/EZF8iD-wwOU"><center><img src="m/img1.jpg" alt="name" style="width:200px"></center><font size="3px"color="#0066cc">#Superhero #RDJ #SUCCESS #Robert Downy Junior</font></a></li>
<li><a href="https://youtu.be/xp0O2vi8DX4"><center><img src="m/img2.jpg" alt="name" style="width:200px"></center><font size="3px" color="#0066cc">#Research #Dr Tali Sarot #Knowledge #Emotions</font></a></li>
<li><a href="https://youtu.be/W5tlGJwvmCQ"><center><img src="m/img3.jpg" alt="name" style="width:200px"></center><font size="3px"color="#0066cc">#Rock #Story #Achievement #Inspiration</font></a></li>
<li><a href="https://youtu.be/LngxdiwFpno"><center><img src="m/img4.jpg" alt="name" style="width:200px"></center><font size="3px"color="#0066cc">#Steve Harvey #Dreams #Success #Failure</font></a></li>
<li><a href="https://youtu.be/eWJVvNptHZ4"><center><img src="m/img5.jpg" alt="name" style="width:200px"></center><font size="3px"color="#0066cc">#Arnold Schwarzenegger #Hardwork #Six rules of success #Focus</font></a></li>
<li><a href="https://youtu.be/Thj5jl2E_Yg"><center><img src="m/img6.jpg" alt="name" style="width:200px"></center><font size="3px"color="#0066cc">#Excitement #Passion #Hope #Goal</font></a></li>
<li><a href="https://youtu.be/g8VRisX_4GU"><center><img src="m/img7.jpg" alt="name" style="width:200px"></center><font size="3px"color="#0066cc">#Motivation #Research #Idea #How to Motivate</font></a></li>
<li><a href="https://youtu.be/g-jwWYX7Jlo"><center><img src="m/img8.jpg" alt="name" style="width:200px"></center><font size="3px"color="#0066cc">#Life #Society #SUCCESS #Motivation</font></a></li>
<li><a href="https://youtu.be/k9zTr2MAFRg"><center><img src="m/img9.jpg" alt="name" style="width:200px"></center><font size="3px"color="#0066cc">#Elon Musk #Against All Odds #Life </font></a></li>
<li><a href="https://youtu.be/L2rR5RuJEPc"><center><img src="m/img10.jpg" alt="name" style="width:200px"></center><font size="3px"color="#0066cc">#J K Rowling #Story #Determination #Faith</font></a></li>

</ul>
</div>
</div>

<script>

function removeElement1(){
document.getElementById("mv1").style.display="none";
}
function removeElement2(){
document.getElementById("mv2").style.display="none";
}
function removeElement3(){
document.getElementById("mv3").style.display="none";
}
function removeElement4(){
document.getElementById("mv4").style.display="none";
}
function removeElement5(){
document.getElementById("mv5").style.display="none";
}
function removeElement6(){
document.getElementById("mv6").style.display="none";
}
function removeElement7(){
document.getElementById("mv7").style.display="none";
}
function removeElement8(){
document.getElementById("mv8").style.display="none";
}
function removeElement9(){
document.getElementById("mv9").style.display="none";
}
function removeElement10(){
document.getElementById("mv10").style.display="none";
}

function myFunction() {
    var input, filter, ul, li, a, i, txtValue;
    input = document.getElementById("myInput");
    filter = input.value.toUpperCase();
    ul = document.getElementById("myUL");
    li = ul.getElementsByTagName("li");
    for (i = 0; i < li.length; i++) {
        a = li[i].getElementsByTagName("a")[0];
        txtValue = a.textContent || a.innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1)
     {        li[i].style.display = "";  } 
   else {
            li[i].style.display = "none";
        }
    }
}


</script>
</body>
</html>