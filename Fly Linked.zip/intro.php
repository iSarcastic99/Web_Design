<!DOCTYPE html>
<html lang="en">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" type="text/css" href="vendors/css/normalize.css">
        <link rel="stylesheet" type="text/css" href="vendors/css/grid.css">
        <link rel="stylesheet" type="text/css" href="vendors/css/ionicons.min.css">
        <link rel="stylesheet" type="text/css" href="vendors/css/animate.css">
        <link rel="stylesheet" type="text/css" href="resources/css/style.css">
        <link rel="stylesheet" type="text/css" href="resources/css/queries.css">
        <link href='http://fonts.googleapis.com/css?family=Lato:100,300,400,300italic' rel='stylesheet' type='text/css'>
        <title>First Love Yourself</title>
    </head>
    <body>
        <header>
            <nav>
                <div class="row">
                    <img src="resources/img/orange-white logo.png" alt="Fly logo" class="logo">
                    <img src="resources/img/orange-white logo.png" alt="Fly logo" class="logo-black">
                    <ul class="main-nav js--main-nav">
                        <li><a href="#story">Share Your Story</a></li>
                        <li><a href="#Info">About us</a></li>
                        <li><a href="#help">Contact us</a></li>
                        <li><a href="registration1.php">Sign up</a></li>
                    </ul>
                    <a class="mobile-nav-icon js--nav-icon"><i class="ion-navicon-round"></i></a>
                </div>
            </nav>
            <div class="hero-text-box">
                <h1>Being Human<br>Is The Best Quality Of Human Being</h1>
                <a class="btn btn-full js--scroll-to-plans" href="login1.php">Let's Go</a>
                <a class="btn btn-ghost js--scroll-to-start" href="#">Show me more</a>
            </div>
            
        </header>
        
        <section class="section-features js--section-features" id="features">
            <div class="row">
                <h2>WE ARE HERE TO &mdash; SPREAD AWARENESS</h2>
                <p class="long-copy">
                    Hello, we're FLY, Our Aim is to improve the mental health of all people in India.! <br>Your support and encouragement can play an important role in your loved one’s recovery. <br><br> <b> IF YOU DON'T HAVE THE REASON TO LIVE THEN LIVE UNTIL YOU FIND ONE TO LIVE.</b>MAY YOUR LIFE BECOMES SEVERAL TIMES BETTER THAN BEFORE.
                </p>
            </div>

        </section>
        
        <section class="section-testimonials">
            <div class="row">
                <h2>Our Mission is to make everyone happy and healthy</h2>
            </div>
            <div class="row">
                <div class="col span-1-of-3">
                    <blockquote>
                        I'm a strong believer in the fact that all are born to be happy not depressed. God has made us like that....
                        <cite><img src="resources/img/author-1.jpg">Deepika Padukone</cite>
                    </blockquote>
                </div>
                <div class="col span-1-of-3">
                    <blockquote>
                            Don't let life discourage you; everyone who got where he is had to begin where he was...
                        <cite><img src="resources/img/author-2.jpg">Richard L. Evans</cite>
                    </blockquote>
                </div>
                <div class="col span-1-of-3">
                    <blockquote>
                        The Present changes the Past. When you look back you do not find what you left behind. Because Life's another name is to live for future...
                    <cite><img src="resources/img/author-3.jfif">Kiran Desai</cite>
                    </blockquote>
                </div>
            </div>
        </section>
        
        
        
        <section class="section-form">
            <div class="row">
                <h2>We're happy to hear what you want to say</h2>
            </div>
            <div class="row">
                <form method="post" action="#" class="contact-form">
                    <div class="row">
                        <div class="col span-1-of-3">
                            <label for="name">Name</label>
                        </div>
                        <div class="col span-2-of-3">
                            <input type="text" name="name" id="name" placeholder="Your name" required>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col span-1-of-3">
                            <label for="email">Email</label>
                        </div>
                        <div class="col span-2-of-3">
                            <input type="email" name="email" id="email" placeholder="Your email" required>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col span-1-of-3">
                            <label>Drop us a line</label>
                        </div>
                        <div class="col span-2-of-3">
                            <textarea name="message" placeholder="Your message"></textarea>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col span-1-of-3">
                            <label>&nbsp;</label>
                        </div>
                        <div class="col span-2-of-3">
                            <input type="submit" value="Send it!">
                        </div>
                    </div>
                    
                </form>
                
            </div>
        </section>
        
        <footer>
            <div class="row">
                <div class="col span-1-of-2">
                    <ul class="footer-nav">
                        <li><a href="#">About us</a></li>
                        <li><a href="#">Blog</a></li>
                        <li><a href="#">Android App</a></li>
                    </ul>
                </div>
                <div class="col span-1-of-2">
                    <ul class="social-links">
                        <li><a href="#"><i class="ion-social-facebook"></i></a></li>
                        <li><a href="#"><i class="ion-social-twitter"></i></a></li>
                        <li><a href="#"><i class="ion-social-googleplus"></i></a></li>
                        <li><a href="#"><i class="ion-social-instagram"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="row">
                <p>
                    This webpage was created to treat or help those who tired of being living in this world for some reason.<br>
                    If you are one of them. Then This webpage is for you! So come and live more in this beautiful world.
                </p>
                <p>
                    Build with <i class="ion-ios-heart" style="color: #ea0000; padding: 0 3px;"></i> in the beautiful city of Lisbon, Portugal, March 2015.
                </p>
            </div>
        </footer>
        
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
    <script src="//cdn.jsdelivr.net/respond/1.4.2/respond.min.js"></script>
    <script src="//cdn.jsdelivr.net/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="//cdn.jsdelivr.net/selectivizr/1.0.3b/selectivizr.min.js"></script>
    <script src="vendors/js/jquery.waypoints.min.js"></script>
    <script src="resources/js/script.js"></script>
    
    </body>  
    
</html>