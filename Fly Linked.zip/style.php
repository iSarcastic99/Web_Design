<style>
body{
		height: 100%;
		overflow: hidden;
		padding: 0px;
		margin: 0px;
	}
	     p{
		font-size: 12px;
		font-family: helvetica;
	}
		#container{
		box-shadow: 2px 2px 10px #000000 ;
		width: 1400px;
		height: 70%;
		margin: 2% auto;
		border:2px;
		border-radius: 1%;
		overflow: hidden;
}
        #menu{
        	background: #233070;
        	color: white;
        	padding: 1%;
        	font-size: 30px;
        }
        #left-col,#right-col{
        	float: left;
        	position: relative;
        	height: 90%;

        }
        #left-col{
        	width: 30%;
        }
        #right-col{	
     	width: 70%;
     	border:1px solid #efefef;
        }
        </style>