<?php
session_start();

if(isset($_SESSION['User_Name'])){}
else{
  header("location:login1.php");
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv=""text/html; charset>
<title>Explore the world</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="dashboard.css">
	</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#">
    <div class="img"><img src=logo2.0.png width="50" height="50" alt=""></div>
  </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="#"><?php
    echo "Welcome ".$_SESSION['User_Name'];
    ?><span class="sr-only">(current)</span></a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="dashboard.php">Feed <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="world.php">Explore the world</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="Articles.php">Articles you should read</a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Videos for YOU
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="Humourous.php">Humourous</a>
          <a class="dropdown-item" href="Motivation.php">Motivational</a>
          <a class="dropdown-item" href="comedy.php">Comedy</a>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="counsellor.php">Consult a Counsellor</a>
      </li>
    </ul>
    <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="You are Interested in" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
      <button class="btn btn-outline-danger my-2 my-sm-0" type="submit"><a href="logout.php">Log Out</a></button>
    </form>
  </div>
</nav>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  <style>
* {
    box-sizing: border-box;
}

body
 {
    font-family: Arial, Helvetica, sans-serif;
    margin: 0;
}

.header
 {
    padding: 80px;
    text-align: center;
    background: black;
    color: white;
}

.header h1 {
    font-size: 60px;
}

.navbar
 {
    overflow: hidden;
    background-color: #333;
}

.navbar a
 {
    float: left;
    display: block;
    color: BLACK;
    
text-align: center;
    padding: 14px 20px;
    text-decoration: none;
}

.navbar a.right {
    float: right;
}

.navbar a:hover
 {
    background-color: #ddd;
    color: black;
}


.row
 {  
    display: -ms-flexbox; 
    
display: flex;
    -ms-flex-wrap: wrap; 
    flex-wrap: wrap;
}

.side
 {
    -ms-flex: 30%; 
   
 flex: 30%;
    background-color: #f1f1f1;
    padding: 20px;
}

.main {   
    -ms-flex: 70%; 
    flex: 70%;
    background-color: WHITE;

    padding: 20px;
}

.fakeimg 
{
   background-color: #aaa;
    width: 100%;
    padding: 20px;
}

.footer
 {
    padding: 20px;
    text-align: center;
    background: #ddd;
}


media screen and (max-width: 700px) {
 
.row {   
        flex-direction: column;
    }
}

media screen and (max-width: 400px) {
    .
navbar a {
        float: none;
        width: 100%;
    }
}
</style>
<div class="header" style="background-image: url(90.jpg); height:200px ; width: 100%; border: 1px solid black;">
  <h1>Explore the world</h1>
  <p>TO SEE THE WORLD WITH YOUR EYES.</p>
</div>

<div class="navbar">

  <a href="https://www.holidify.com">More places</a>
 
 <a href="">contact</a>
 

</div>

<div class="row">
  <div class="side">
  
    <h2>Hill station</h2>
      <h4><a href=https://www.holidify.com/places/shimla/>Shimla</a></h4>
      
<div class="fakeimg" style="background-image: url(shimla1.png); height:200px;width:95%; border: 1px solid black;"></div>
     
 <p>Situated at a height of 2200m, Shimla is one of the most popular hill stations in India and is frequented by millions of tourists every year. You will see the complete presence of Mother Nature everywhere in Shimla in Pine and Deodar forest ranges, snow-capped mountain, deep valleys, natural springs, and crystal clear water rivers.that
 making it one of the best places to visit in the india if you 
like a good trick shot or fun selfie!..</p>

 
     
 <div style="background-image: url(shimla2.png); height:200px ; width: 100%; border: 1px solid black;"></div><br>
      
<div style="background-image: url(1.31.jpg); height:200px ; width: 100%; border: 1px solid black;"></div><br>
     
 <div style="background-image: url(shimla3.png); height:200px ; width: 100%; border: 1px solid black;"></div>
 <br>
 <a href="https://www.holidify.com/collections/hill-stations-of-india">view more hill stations</a>
  </div>

  <div class="main">

      <h2>Beach</h2>
      
<h4> <a href="https://www.holidify.com/places/goa/">Goa</a></h4>
      
<div style="background-image: url(goa1.jpg); height:200px ; width: 100%; border: 1px solid black;">
</div>

<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>  

     
 <p>Goa is visited by beach tour enthusiasts, nature tour lovers, couples very much. Goa is much more than just beaches and sea. It has a soul which goes deep into unique history, rich culture and some of the prettiest natural scenery that India has to offer.
  Much of the real Goa is in its interiors, both inside its buildings and in the hinterland away from the coastal area.The state of Maharashtra borders Goa on the north, the state of Karnataka on the south and east. The vast expanse of the Arabian Sea on the west forms the magnificent coastline for which Goa is justly famous.</p>
  <a href="https://www.holidify.com/collections/best-beaches-in-india">view more beaches</a>
      <br>
      
<h2>Heritage</h2>
      <h5><a href="">Fort&Historical Places</a></h5>
      
<div style="background-image: url(fort1.png); height:200px ; width: 100%; border: 1px solid black;"height:200px;"></div>

      
<p>The Gwalior fort spreads out over an area of 3 square km, surrounded by concrete walls of sandstone. The Gwalior fort encloses three temples, six palaces and numerous water tanks. At a point of time Gwalior fort was regarded as North and Central India's most invincible fortress. The fort was built by Raja Man Singh Tomar in the 15th century. The fort of Gwalior has seen many ups and downs of history. In the course of almost five hundred years, the Gwalior fort went from one ruler to another. .</p>
<br>
<a href="https://www.holidify.com/collections/historical-places-in-india">view more places</a>

  </div>
</div>

<div>
  

</div>




</center>

</body>
</html>