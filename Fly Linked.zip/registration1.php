<!DOCTYPE html>
<html>
<head>
<style>
form {

background-color: black;
opacity:0.8;
padding: 10px;
font-size: inherit:
align:right;

}

body {
font-family:lato,sans-serif;
background-color: black;
background:url(girllye.png);
background-repeat: no-repeat;
background-size:100%;
}
label {
color: #ff7500;
}
input[type="password"] {
display: block;
margin-buttom: 25px;
width: 90%;
border: 1px solid;
color: #ff7500;
background-color : black;
}
input[type="text"] {
display: block;
margin-buttom: 25px;
width: 90%;
border: 1px solid;
color: #ff7500;
background-color : black;
}
input[type="E-mail"] {
display: block;
margin-buttom: 25px;
width: 90%;
border: 1px solid;
color: #ff7500;
background-color : black;
}
input[type="submit"] {
display: block;
margin-buttom: 25px;;
background-color: #ff7500;
}


h2 {
color:#ff7500;
background-size:auto;
font-family:arial;
font-size:40px;
}

input {
padding: 10px;
font-size: inherit:
}
</style>
	<title>Register yourself</title>
	<link rel="stylesheet" type="text/css" href="design.css">
</head>
<body>
	<?php
	include 'connection.php';
	if (isset($_POST['Register'])){

		$full_name=$_POST['full_name'];
		$email=$_POST['email'];
		$User_Name=$_POST['User_Name'];
		$password=$_POST['password'];
		if($full_name !="" and $email!="" and $User_Name!="" and $password!=""){

		 $q="INSERT INTO `register` (full_name,email,user_name,password)
                VALUES ('".$full_name."','".$email."','".$User_Name."','".$password."')";
			
			if(mysqli_query($reg,$q)){
				
				echo "SUCCESSFULL!!!";
				header("location:login1.php");
			}
			else{
				
				echo "Signup failed";
			}
		}
		else{
			echo "all the details are mendatory";
		}
	}
	function check($data)
{

       $data = trim($data);
       $data = stripslashes($data);
       $data = htmlspecialchars($data);
       return $data;
    }
	?>
<div id="main">
	<h2 align="center">Register Yourself</h2>
	
		<form method="post">
		<label>Full Name:</label>
		<input type="text" name="full_name"><br><br>
		<label>E-mail:</label>
		<input type="E-mail" name="email"><br><br>
		<label>UserName:</label>
		<input type="text" name="User_Name"><br><br>
		<label>Password:</label>
		<input type="password" name="password"><br><br>
		<input type="submit" name="Register" value="Register">
                 
	</form>
</center>
</div>
</body>
</html>