<?php
session_start();
include 'connection.php';
if(isset($_SESSION['User_Name']) and isset($_GET['user'])){
if(isset($_POST['text'])){
if($_POST['text'] !=''){
$sender_name=$_SESSION['User_Name'];
$reciever_name=$_GET['user'];
$message=$_POST['text'];
$date= date("Y-m-d h:i:s");
$q='INSERT INTO `chat` (`sender_name`,`reciever_name`,`message_text`,`date_time`)
		VALUES ("'.$sender_name.'","'.$reciever_name.'","'.$message.'","'.$date.'")';
		$r=mysqli_query($reg,$q);
if($r){
	?>
	<div class="grey-message">
    			<a href="#">Me</a>
    			<p><?php echo $message; ?></p>
	</div>
	<?php
}
else{
	echo("Error description: " . mysqli_error($reg));
}
}
else{
	echo 'Please write something first' ;
}
}
else{
	echo 'problem with text' ;
}
}
else{
	echo 'Please login or select a user to start a chat session' ;
}
?>